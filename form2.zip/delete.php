<?php
$id = $_GET['id'];
$conn = mysqli_connect("localhost", "root", "seasia@123", "records") or die ("connection failed");
$sql = "DELETE FROM student WHERE id = {$id}";
$result = mysqli_query($conn, $sql) or die ("query unsucessful");
header("location: http://localhost/php/record.php");
mysqli_close($conn);
?>